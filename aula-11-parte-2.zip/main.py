__author__ = 'Thauane'

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

qtde = int(input('informe a quantidade de cigarros que você fuma por dia: '))
anos = int(input('informe por quantos nos você fuma: '))

soma = qtde*(anos*365)
minutos = soma*10

subtrai = (minutos/60)/24

print('você tem %.2f dias a menos de vida'%subtrai)

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

print('-----Calculadora de dias de carro alugado-----\n')

d = int(input('quantos dias o carro ficou alugado?: '))
k = float(input('\nquantos km o carro rodou?: ').replace(',','.'))

paga=(d*60)+(k*0.15)

print('\no aluguel do carro fico por R${:.2f} devido a {:.0f} dias de aluguel e {:.0f} quilômetros rodados'.format(paga,d,k))

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

print('-----Conversor de temperatura celsius para fahrenheint-----')

c = float(input('insira a temperatura em celsius: ').replace(',','.'))
f = (9*(c/5)+32)
print('Fahrenheint : {:.2f}'.format(f))

#ºC = (ºF - 32)/ 1,8

print('\n\n-----Conversor de temperatura fahrenheint para celsius-----')

f = float(input('insira a temperatura em fahrenheint: ').replace(',','.'))
c = ((f-32)/1.8)
print('Celsius : {:.2f}'.format(c))